## what to do if you don't have python on your pc 
- download exe version [clickhere](soon!)


## How to install 
- run main.py


## Features
- Clone Channels
- Channel Permissions
- Server Roles
- Server Name
- Server Banner / Avatar
- Server Emojis
- Server Settings 
